#include<stdio.h>
#include<locale.h>
#include<iostream>

main () {
	setlocale(LC_ALL, "portuguese");
	printf("Olá, Mundo!\n");
	system("pause");
}
